# ZIB Measurement Scripts

## Files

| File | Purpose |
|---|---|
| `job.sh` | Slurm batch script — submit this to ZIB |
| `train.py` | ResNet-50 training on ImageNet (4 repeated runs) |
| `inference.py` | ResNet-50 inference on ImageNet validation set (4 runs) |
| `monitor.py` | Passive monitoring script — runs concurrently, collects all metrics |

---

## How it works

1. Slurm starts the job on an A100 node
2. `monitor.py` starts in the **background** on the CPU, sampling every 5 seconds
3. `train.py` runs 4 training runs — writes current phase to `current_phase.txt`
4. `inference.py` runs 4 inference runs — also updates `current_phase.txt`
5. `monitor.py` reads the phase file at each sample, so every row in the CSV is labeled
6. After both scripts finish, the monitor is stopped and `measurements.csv` is the output

---

## Output: measurements.csv

Each row is one 5-second sample with the following columns:

| Column | Source | Description |
|---|---|---|
| `timestamp` | system | ISO 8601 datetime |
| `phase` | state file | e.g. `training_run_1`, `inference_run_2`, `idle` |
| `gpu_power_w` | nvidia-smi | GPU power draw in Watts |
| `gpu_util_pct` | nvidia-smi | GPU compute utilization % |
| `gpu_mem_util_pct` | nvidia-smi | GPU memory bandwidth utilization % |
| `gpu_mem_used_mb` | nvidia-smi | GPU memory used in MB |
| `gpu_mem_total_mb` | nvidia-smi | Total GPU memory in MB |
| `cpu_util_pct` | /proc/stat | CPU utilization % |
| `mem_total_mb` | free | Total RAM in MB |
| `mem_used_mb` | free | Used RAM in MB |
| `mem_free_mb` | free | Free RAM in MB |
| `net_rx_bytes` | ip -s link | Cumulative bytes received |
| `net_tx_bytes` | ip -s link | Cumulative bytes sent |
| `node_power_w` | ipmitool | Total node power draw in Watts |

---

## Before submitting

1. Update `DATA_DIR` in `job.sh` to the actual ImageNet path on ZIB storage
2. Confirm the correct Slurm partition name with ZIB (currently set to `gpu`)
3. Confirm module names/versions available on the cluster
4. Run a short test job first to verify nvidia-smi and ipmitool are accessible

## Submit the job

```bash
sbatch job.sh
```

## Monitor job progress

```bash
squeue -u $USER
tail -f logs/job_<JOB_ID>.out
```
