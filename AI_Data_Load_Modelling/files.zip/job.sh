#!/bin/bash
# =============================================================================
# job.sh  –  Slurm batch script for ZIB NHR cluster
#
# Submits a single-GPU ResNet-50 measurement job.
# Starts the monitor in the background, runs training, then inference,
# then stops the monitor. All output goes to logs/.
#
# Submit with:
#   sbatch job.sh
# =============================================================================

#SBATCH --job-name=resnet50_measurement
#SBATCH --partition=gpu                  # adjust to correct ZIB partition name
#SBATCH --gres=gpu:a100:1               # 1x A100 GPU
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4               # 4 CPU cores for data loading
#SBATCH --mem=32G
#SBATCH --time=06:00:00                 # 6h wall time (conservative estimate)
#SBATCH --output=logs/job_%j.out
#SBATCH --error=logs/job_%j.err

# ── Environment setup ─────────────────────────────────────────────────────────
echo "=============================="
echo " Job ID   : $SLURM_JOB_ID"
echo " Node     : $SLURMD_NODENAME"
echo " Start    : $(date)"
echo "=============================="

mkdir -p logs

# Load required modules (adjust version numbers to what ZIB has available)
module load python/3.10
module load cuda/12.1

# Install Python dependencies into a local user environment if not pre-installed
pip install --quiet --user torch torchvision

# ── Configuration ─────────────────────────────────────────────────────────────
# !! IMPORTANT: Update DATA_DIR to the actual ImageNet path on ZIB storage !!
DATA_DIR="/path/to/imagenet"

NUM_TRAINING_RUNS=4
NUM_INFERENCE_RUNS=4

# ── Start monitoring script in background ────────────────────────────────────
echo "[job] Starting monitor..."
python monitor.py > logs/monitor_${SLURM_JOB_ID}.log 2>&1 &
MONITOR_PID=$!
echo "[job] Monitor PID: $MONITOR_PID"

# Give monitor a moment to initialise
sleep 5

# ── Training phase ────────────────────────────────────────────────────────────
echo ""
echo "[job] Starting training phase..."
python train.py \
    --data_dir  "$DATA_DIR" \
    --num_runs  $NUM_TRAINING_RUNS

echo "[job] Training phase complete."

# Brief pause between phases
sleep 10

# ── Inference phase ───────────────────────────────────────────────────────────
echo ""
echo "[job] Starting inference phase..."
python inference.py \
    --data_dir   "$DATA_DIR" \
    --checkpoint "resnet50_run1.pth" \
    --num_runs   $NUM_INFERENCE_RUNS

echo "[job] Inference phase complete."

# Brief pause before stopping monitor
sleep 10

# ── Stop monitoring script ────────────────────────────────────────────────────
echo ""
echo "[job] Stopping monitor (PID $MONITOR_PID)..."
kill $MONITOR_PID
wait $MONITOR_PID 2>/dev/null

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "=============================="
echo " Job finished : $(date)"
echo " Measurements : measurements.csv"
echo " Logs         : logs/"
echo "=============================="
