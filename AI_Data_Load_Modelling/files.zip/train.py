"""
train.py
--------
Runs ResNet-50 training on ImageNet (2012) for a given number of repeated runs.
Writes the current phase to current_phase.txt so monitor.py can label measurements.

Usage:
    python train.py --data_dir /path/to/imagenet --num_runs 4
"""

import argparse
import os
import time

import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.models as models
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision.datasets import ImageNet

STATE_FILE = "current_phase.txt"


def set_phase(phase: str):
    """Write current phase so the monitor can label its measurements."""
    with open(STATE_FILE, "w") as f:
        f.write(phase)
    print(f"[train] Phase → {phase}")


def get_data_loader(data_dir: str, batch_size: int, num_workers: int) -> DataLoader:
    transform = transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225]),
    ])
    dataset = ImageNet(root=data_dir, split="train", transform=transform)
    return DataLoader(dataset, batch_size=batch_size, shuffle=True,
                      num_workers=num_workers, pin_memory=True)


def run_training(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[train] Device: {device}")

    loader = get_data_loader(args.data_dir, batch_size=64, num_workers=4)

    for run in range(1, args.num_runs + 1):
        print(f"\n[train] ── Run {run}/{args.num_runs} ──────────────────────")
        set_phase(f"training_run_{run}")

        # Re-initialise model for every run (ensures independent measurements)
        model     = models.resnet50(weights=None).to(device)
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.SGD(model.parameters(), lr=0.01,
                              momentum=0.9, weight_decay=1e-4)

        model.train()
        start = time.time()

        for batch_idx, (inputs, labels) in enumerate(loader):
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            loss = criterion(model(inputs), labels)
            loss.backward()
            optimizer.step()

            if batch_idx % 200 == 0:
                elapsed = time.time() - start
                print(f"  Batch {batch_idx:>5}/{len(loader)}  "
                      f"loss={loss.item():.4f}  elapsed={elapsed:.0f}s")

        total_time = time.time() - start
        print(f"[train] Run {run} finished in {total_time:.1f}s")

        # Save checkpoint so inference.py can load it
        ckpt_path = f"resnet50_run{run}.pth"
        torch.save(model.state_dict(), ckpt_path)
        print(f"[train] Checkpoint saved → {ckpt_path}")

    set_phase("idle")
    print("\n[train] All runs complete.")


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ResNet-50 training on ImageNet")
    parser.add_argument("--data_dir",  type=str, required=True,
                        help="Root directory of ImageNet dataset")
    parser.add_argument("--num_runs",  type=int, default=4,
                        help="Number of repeated training runs (default: 4)")
    run_training(parser.parse_args())
