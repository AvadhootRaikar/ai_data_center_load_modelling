"""
monitor.py
----------
Passive monitoring script that runs concurrently alongside training/inference.
Collects GPU, CPU, memory, network, and node-level power at ~5s intervals.
Reads the current phase from a shared state file written by train.py / inference.py.
All measurements are saved to measurements.csv.
"""

import subprocess
import csv
import time
import os
import datetime

INTERVAL = 5          # seconds between each sample
OUTPUT_FILE = "measurements.csv"
STATE_FILE  = "current_phase.txt"   # shared with train.py / inference.py


# ── Metric collectors ────────────────────────────────────────────────────────

def get_gpu_metrics():
    """Query nvidia-smi for power, utilization and memory."""
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=power.draw,utilization.gpu,utilization.memory,"
                "memory.used,memory.total",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True, text=True, timeout=10
        )
        parts = [p.strip() for p in result.stdout.strip().split(",")]
        return {
            "gpu_power_w":        parts[0],
            "gpu_util_pct":       parts[1],
            "gpu_mem_util_pct":   parts[2],
            "gpu_mem_used_mb":    parts[3],
            "gpu_mem_total_mb":   parts[4],
        }
    except Exception:
        return {k: "N/A" for k in
                ["gpu_power_w", "gpu_util_pct", "gpu_mem_util_pct",
                 "gpu_mem_used_mb", "gpu_mem_total_mb"]}


def get_cpu_metrics():
    """Read CPU utilization via /proc/stat (no extra dependencies)."""
    try:
        def read_cpu():
            with open("/proc/stat") as f:
                line = f.readline()
            vals = list(map(int, line.split()[1:]))
            idle  = vals[3]
            total = sum(vals)
            return idle, total

        idle1, total1 = read_cpu()
        time.sleep(0.2)
        idle2, total2 = read_cpu()
        utilization = 100.0 * (1 - (idle2 - idle1) / (total2 - total1))
        return {"cpu_util_pct": f"{utilization:.1f}"}
    except Exception:
        return {"cpu_util_pct": "N/A"}


def get_memory_metrics():
    """Parse 'free -m' for total / used / free RAM in MB."""
    try:
        result = subprocess.run(["free", "-m"], capture_output=True, text=True, timeout=10)
        parts = result.stdout.strip().split("\n")[1].split()
        return {
            "mem_total_mb": parts[1],
            "mem_used_mb":  parts[2],
            "mem_free_mb":  parts[3],
        }
    except Exception:
        return {k: "N/A" for k in ["mem_total_mb", "mem_used_mb", "mem_free_mb"]}


def get_network_metrics():
    """Parse 'ip -s link' for cumulative RX/TX bytes on the first active interface."""
    try:
        result = subprocess.run(["ip", "-s", "link"], capture_output=True, text=True, timeout=10)
        lines  = result.stdout.strip().split("\n")
        rx, tx = "N/A", "N/A"
        for i, line in enumerate(lines):
            if "RX:" in line and i + 1 < len(lines):
                rx = lines[i + 1].strip().split()[0]
            if "TX:" in line and i + 1 < len(lines):
                tx = lines[i + 1].strip().split()[0]
                break
        return {"net_rx_bytes": rx, "net_tx_bytes": tx}
    except Exception:
        return {"net_rx_bytes": "N/A", "net_tx_bytes": "N/A"}


def get_ipmi_power():
    """Query ipmitool for node-level power draw (requires IPMI access on cluster)."""
    try:
        result = subprocess.run(
            ["ipmitool", "sdr", "type", "Current"],
            capture_output=True, text=True, timeout=15
        )
        for line in result.stdout.split("\n"):
            if any(kw in line for kw in ("Pwr", "Power", "Watts")):
                parts = line.split("|")
                if len(parts) >= 2:
                    val = parts[-1].strip().split()[0]
                    return {"node_power_w": val}
        return {"node_power_w": "N/A"}
    except Exception:
        return {"node_power_w": "N/A"}


def get_current_phase():
    """Read the current workload phase written by train.py / inference.py."""
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE) as f:
                return f.read().strip()
        return "idle"
    except Exception:
        return "unknown"


# ── Main loop ─────────────────────────────────────────────────────────────────

def main():
    fieldnames = [
        "timestamp", "phase",
        "gpu_power_w", "gpu_util_pct", "gpu_mem_util_pct",
        "gpu_mem_used_mb", "gpu_mem_total_mb",
        "cpu_util_pct",
        "mem_total_mb", "mem_used_mb", "mem_free_mb",
        "net_rx_bytes", "net_tx_bytes",
        "node_power_w",
    ]

    print(f"[monitor] Starting. Writing to {OUTPUT_FILE} every {INTERVAL}s.")

    with open(OUTPUT_FILE, "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        while True:
            row = {
                "timestamp": datetime.datetime.now().isoformat(),
                "phase":     get_current_phase(),
                **get_gpu_metrics(),
                **get_cpu_metrics(),
                **get_memory_metrics(),
                **get_network_metrics(),
                **get_ipmi_power(),
            }
            writer.writerow(row)
            csvfile.flush()   # ensure data is written even if job is killed
            time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
