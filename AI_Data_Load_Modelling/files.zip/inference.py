"""
inference.py
------------
Runs ResNet-50 inference on the ImageNet 2012 validation set for a given
number of repeated runs.  Loads the checkpoint saved by train.py (run 1 by
default).  Writes the current phase to current_phase.txt so monitor.py can
label measurements.

Usage:
    python inference.py --data_dir /path/to/imagenet
    python inference.py --data_dir /path/to/imagenet --checkpoint resnet50_run1.pth --num_runs 4
"""

import argparse
import time

import torch
import torchvision.models as models
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision.datasets import ImageNet

STATE_FILE = "current_phase.txt"


def set_phase(phase: str):
    """Write current phase so the monitor can label its measurements."""
    with open(STATE_FILE, "w") as f:
        f.write(phase)
    print(f"[inference] Phase → {phase}")


def get_data_loader(data_dir: str, batch_size: int, num_workers: int) -> DataLoader:
    transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225]),
    ])
    dataset = ImageNet(root=data_dir, split="val", transform=transform)
    return DataLoader(dataset, batch_size=batch_size, shuffle=False,
                      num_workers=4, pin_memory=True)


def run_inference(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[inference] Device: {device}")

    # Load model
    model = models.resnet50(weights=None)
    if args.checkpoint:
        model.load_state_dict(torch.load(args.checkpoint, map_location=device))
        print(f"[inference] Loaded checkpoint: {args.checkpoint}")
    else:
        print("[inference] No checkpoint provided — using random weights.")
    model = model.to(device)
    model.eval()

    loader = get_data_loader(args.data_dir, batch_size=64, num_workers=4)

    for run in range(1, args.num_runs + 1):
        print(f"\n[inference] ── Run {run}/{args.num_runs} ────────────────────")
        set_phase(f"inference_run_{run}")

        correct = 0
        total   = 0
        start   = time.time()

        with torch.no_grad():
            for batch_idx, (inputs, labels) in enumerate(loader):
                inputs, labels = inputs.to(device), labels.to(device)
                outputs        = model(inputs)
                _, predicted   = torch.max(outputs, 1)
                total   += labels.size(0)
                correct += (predicted == labels).sum().item()

                if batch_idx % 100 == 0:
                    print(f"  Batch {batch_idx:>4}/{len(loader)}")

        elapsed  = time.time() - start
        accuracy = 100.0 * correct / total
        print(f"[inference] Run {run} finished — "
              f"accuracy={accuracy:.2f}%  time={elapsed:.1f}s")

    set_phase("idle")
    print("\n[inference] All runs complete.")


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ResNet-50 inference on ImageNet")
    parser.add_argument("--data_dir",   type=str, required=True,
                        help="Root directory of ImageNet dataset")
    parser.add_argument("--checkpoint", type=str, default="resnet50_run1.pth",
                        help="Path to model checkpoint (default: resnet50_run1.pth)")
    parser.add_argument("--num_runs",   type=int, default=4,
                        help="Number of repeated inference runs (default: 4)")
    run_inference(parser.parse_args())
